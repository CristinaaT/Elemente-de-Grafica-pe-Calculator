#include "Laborator5.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>


using namespace std;

Laborator5::Laborator5()
{
}

Laborator5::~Laborator5()
{
}

void Laborator5::Init()
{
	renderCameraTarget = false;

	camera = new Laborator::Camera();
	camera->Set(glm::vec3(0, 2, 3.5f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("quad");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "quad.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("Heart");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "Heart.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	// Create a shader program for drawing face polygon with the color of the normal
	{
		Shader* shader = new Shader("MyShader");
		shader->AddShader("Source/Laboratoare/Laborator5/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Laborator5/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	//Light & material properties
	{
		lightPosition = glm::vec3(0, 1, 1);
		materialShininess = 30;
		materialKd = 0.5;
		materialKs = 0.5;
	}

	projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);
}

void Laborator5::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// sets the screen area where to draw
	glm::ivec2 resolution = window->GetResolution();
	glViewport(0, 0, resolution.x, resolution.y);
}

void Laborator5::Update(float deltaTimeSeconds)
{
	//Corpul avionului
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-1, translateY, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.35, 0.35, 0.35));
		if (end_game == true)
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 1));
		else
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 0));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 0.35, 1));
	}

	//Aripile avionului
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-1, translateY, 0.4));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.125, 0.05, 0.25));
		if (end_game == true)
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 1));
		else
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 0));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 0.35, 1));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-1, translateY, -0.2));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.125, 0.05, 0.25));
		if (end_game == true)
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 1));
		else
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 0));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 0.35, 1));
	}

	//Coada avionului
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.205, (translateY + 0.05), 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.075, 0.125, 0.075));
		if (end_game == true)
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 1));
		else
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 0));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}

	//Suport elice
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.795, translateY, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		if (end_game == true)
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 1));
		else
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 0));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}

	//Elice
	{
		angle_elice += 250 * deltaTimeSeconds;
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.755, translateY, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.025, 0.25, 0.025));
		if (end_game == false)
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_elice), glm::vec3(1, 0, 0));
		if (end_game == true)
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 1));
		else
			modelMatrix = glm::rotate(modelMatrix, RADIANS(angle), glm::vec3(0, 1, 0));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}

	//Marea
	{
		angle_mare += 50 * deltaTimeSeconds;
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.75, 0));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(6, 2, 3));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_mare), glm::vec3(0, 0, 1));
		RenderMesh(meshes["sphere"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0.5, 1));
	}

	//Nori grup 1
	if (translateN1 < -3)
		translateN1 = 3.5;
	else translateN1 -= deltaTimeSeconds;
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(translateN1, 1.9, -0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25, 0.25, 0.25));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3((translateN1-0.2), 1.85, -0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2, 0.2, 0.2));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(30), glm::vec3(0, 1, 1));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3((translateN1 + 0.2), 1.9, -0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.15, 0.15, 0.15));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(60), glm::vec3(1, 1, 0));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}

	//Nori grup 2
	if (translateN2 < -3)
		translateN2 = 3.5;
	else translateN2 -= deltaTimeSeconds;
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(translateN2, 1.9, -0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25, 0.25, 0.25));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3((translateN2 - 0.2), 1.85, -0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2, 0.2, 0.2));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(30), glm::vec3(1, 0, 1));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3((translateN2 + 0.2), 1.9, -0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.15, 0.15, 0.15));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(60), glm::vec3(1, 0, 1));
		RenderMesh(meshes["box"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
	}

	//Vieti
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		if (lives >= 1)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-2, 2, 0));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.03, 0.03, 0.03));
		RenderMesh(meshes["Heart"], shaders["MyShader"], modelMatrix, glm::vec3(1, 0, 0));

	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		if (lives >= 2)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-2.15, 2, 0));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.03, 0.03, 0.03));
		RenderMesh(meshes["Heart"], shaders["MyShader"], modelMatrix, glm::vec3(1, 0, 0));

	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		if (lives >= 3)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-2.3, 2, 0));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.03, 0.03, 0.03));
		RenderMesh(meshes["Heart"], shaders["MyShader"], modelMatrix, glm::vec3(1, 0, 0));
	}

	//Combustibil
	if (end_game == false)
		score = score + 1;
	if (score % 500 == 0)
		ok++;
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(1.8, 2.1, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		if (ok >= 5)
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
		else 
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0, 0));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(1.9, 2.1, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		if (ok >= 4)
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
		else
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0, 0));

	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(2, 2.1, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		if (ok >= 3)
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
		else
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0, 0));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(2.1, 2.1, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		if (ok >= 2)
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
		else
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0, 0));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(2.2, 2.1, 0.1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		if (ok >= 1)
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 1));
		else
			RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0, 0));
	}

	//Bonus Combustibil
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		if (end_game == true)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3((translateX2 + 2), 1.25, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_elice), glm::vec3(1, 1, 1));
		RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0, 0));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		if (end_game == true)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3((translateX4 + 2), 1.25, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05, 0.05, 0.05));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_elice), glm::vec3(1, 1, 1));
		RenderMesh(meshes["quad"], shaders["MyShader"], modelMatrix, glm::vec3(0, 0, 0));
	}

	//Obstacole
	//1
	{
		if (translateX1 < -3)
			translateX1 = 10.5;
		else 
			translateX1 -= deltaTimeSeconds;
		glm::mat4 modelMatrix = glm::mat4(1);
		if (end_game == true)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3(translateX1, 1.25, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.15, 0.15, 0.15));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_elice), glm::vec3(0, 1, 1));
		RenderMesh(meshes["sphere"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 0.1));
	}
	//2
	{
		if (translateX2 < -3)
			translateX2 = 10.5;
		else 
			translateX2 -= deltaTimeSeconds;
		glm::mat4 modelMatrix = glm::mat4(1);
		if (end_game == true)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3(translateX2, 1.75, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.15, 0.15, 0.15));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_elice), glm::vec3(1, 0, 1));
		RenderMesh(meshes["sphere"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 0.1));
	}
	//3
	{
		if (translateX3 < -3)
			translateX3 = 10.5;
		else 
			translateX3 -= deltaTimeSeconds;
		glm::mat4 modelMatrix = glm::mat4(1);
		if (end_game == true)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3(translateX3, 1, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.15, 0.15, 0.15));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_elice), glm::vec3(1, 1, 0));
		RenderMesh(meshes["sphere"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 0.1));
	}
	//4
	{
		if (translateX4 < -3)
			translateX4 = 10.5;
		else 
			translateX4 -= deltaTimeSeconds;
		glm::mat4 modelMatrix = glm::mat4(1);
		if (end_game == true)
			modelMatrix = glm::translate(modelMatrix, glm::vec3(3, 3, 0));
		else
			modelMatrix = glm::translate(modelMatrix, glm::vec3(translateX4, 1.5, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.15, 0.15, 0.15));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(angle_elice), glm::vec3(1, 1, 0));
		RenderMesh(meshes["sphere"], shaders["MyShader"], modelMatrix, glm::vec3(1, 1, 0.1));
	}

	if ((lives > 3) || (ok == 5))
		end_game = true;
	if (end_game == true) {
		translateY -= deltaTimeSeconds;
		angle = -30;
	}
}

void Laborator5::FrameEnd()
{
	DrawCoordinatSystem(camera->GetViewMatrix(), projectionMatrix);
}

void Laborator5::RenderMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, const glm::vec3& color)
{
	if (!mesh || !shader || !shader->GetProgramID())
		return;

	// render an object using the specified shader and the specified position
	glUseProgram(shader->program);

	// Set shader uniforms for light & material properties
	// TODO: Set light position uniform
	GLint loc_light_position = glGetUniformLocation(shader->program, "light_position");
	glUniform3fv(loc_light_position, 1, glm::value_ptr(lightPosition));

	/*// TODO: Set eye position (camera position) uniform
	glm::vec3 eyePosition = GetSceneCamera()->GetWorldPosition();
	GLint loc_eye_position = glGetUniformLocation(shader->program, "eye_position");
	glUniform3fv(loc_eye_position, 1, glm::value_ptr(eyePosition));*/

	// TODO: Set material property uniforms (shininess, kd, ks, object color) 
	GLint loc = glGetUniformLocation(shader->program, "material_shininess");
	glUniform1i(loc, materialShininess);

	loc = glGetUniformLocation(shader->program, "material_kd");  // componenta difuza
	glUniform1f(loc, materialKd);

	loc = glGetUniformLocation(shader->program, "material_ks");  // componenta speculara
	glUniform1f(loc, materialKs);

	loc = glGetUniformLocation(shader->program, "object_color");
	glUniform3fv(loc, 1, glm::value_ptr(color));

	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	// Bind view matrix
	glm::mat4 viewMatrix = GetSceneCamera()->GetViewMatrix();
	int loc_view_matrix = glGetUniformLocation(shader->program, "View");
	glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	// Bind projection matrix
	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
	glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	// Draw the object
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);
}


// Documentation for the input functions can be found in: "/Source/Core/Window/InputController.h" or
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/Window/InputController.h

void Laborator5::OnInputUpdate(float deltaTime, int mods)
{
	// move the camera only if MOUSE_RIGHT button is pressed
	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float cameraSpeed = 2.0f;

		if (window->KeyHold(GLFW_KEY_W)) {
			// TODO : translate the camera forward
			camera->TranslateForward(deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_A)) {
			// TODO : translate the camera to the left
			camera->TranslateRight(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_S)) {
			// TODO : translate the camera backwards
			camera->TranslateForward(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_D)) {
			// TODO : translate the camera to the right
			camera->TranslateRight(deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_Q)) {
			// TODO : translate the camera down
			camera->TranslateUpword(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_E)) {
			// TODO : translate the camera up
			camera->TranslateUpword(deltaTime * cameraSpeed);
		}
	}

	else {
		if (window->KeyHold(GLFW_KEY_C) && isOrtho == false) {
			orthoLeft = -8.0f;
			orthoRight = 8.0f;
			orthoUp = 4.5f;
			orthoDown = -4.5;
			projectionMatrix = glm::ortho(orthoLeft, orthoRight, orthoDown, orthoUp, 0.0f, 200.0f);
			isOrtho = true;
		}

		// increase height
		if (window->KeyHold(GLFW_KEY_UP) && isOrtho) {
			orthoUp += deltaTime;
			orthoDown -= deltaTime;
			projectionMatrix = glm::ortho(orthoLeft, orthoRight, orthoDown, orthoUp, 0.0f, 200.0f);
		}

		// increase height
		if (window->KeyHold(GLFW_KEY_DOWN) && isOrtho) {
			orthoUp -= deltaTime;
			orthoDown += deltaTime;
			projectionMatrix = glm::ortho(orthoLeft, orthoRight, orthoDown, orthoUp, 0.0f, 200.0f);
		}

		// increase length
		if (window->KeyHold(GLFW_KEY_RIGHT) && isOrtho) {
			orthoRight += deltaTime;
			orthoLeft -= deltaTime;
			projectionMatrix = glm::ortho(orthoLeft, orthoRight, orthoDown, orthoUp, 0.0f, 200.0f);
		}

		// decrease length
		if (window->KeyHold(GLFW_KEY_LEFT) && isOrtho) {
			orthoRight -= deltaTime;
			orthoLeft += deltaTime;
			projectionMatrix = glm::ortho(orthoLeft, orthoRight, orthoDown, orthoUp, 0.0f, 200.0f);
		}

		// FOV normal
		if (window->KeyHold(GLFW_KEY_C) && isOrtho)
		{
			projectionMatrix = glm::perspective(90.f, 2.f, 2.f, 200.0f);
			isOrtho = false;
		}
	}
}

void Laborator5::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_T) {
		renderCameraTarget = !renderCameraTarget;
	}

}

void Laborator5::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator5::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event

	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float sensivityOX = 0.001f;
		float sensivityOY = 0.001f;

		if (window->GetSpecialKeyState() == 0) {
			renderCameraTarget = false;
			// TODO : rotate the camera in First-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateFirstPerson_OX(-2 * sensivityOX * deltaY);
			camera->RotateFirstPerson_OY(-2 * sensivityOY * deltaX);
		}

		if (window->GetSpecialKeyState() && GLFW_MOD_CONTROL) {
			renderCameraTarget = true;
			// TODO : rotate the camera in Third-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateThirdPerson_OX(-2 * sensivityOX * deltaY);
			camera->RotateThirdPerson_OY(-2 * sensivityOY * deltaX);
		}

	}

	if (end_game == false){
		if (deltaY > 0) {
			translateY -= 0.015;
			angle = -30;
		}
		else {
			translateY += 0.015;
			angle = 30;
		}
	}
}

void Laborator5::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Laborator5::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator5::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator5::OnWindowResize(int width, int height)
{
}
