#include "Laborator3.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace std;

Laborator3::Laborator3()
{
}

Laborator3::~Laborator3()
{
}

void Laborator3::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);
	float squareSide = 100;

	//PiuPiu
	//Iris
	Mesh* iris = Object2D::CreateSquare("iris", corner, 5, glm::vec3(0, 0, 0), true);
	AddMeshToList(iris);

	//Ochi
	Mesh* eye = Object2D::CreateSquare("eye", corner, squareSide/4, glm::vec3(1, 1, 1), true);
	AddMeshToList(eye);

	//Corp
	Mesh* square = Object2D::CreateSquare("square", corner, squareSide, glm::vec3(1, 1, 0), true);
	AddMeshToList(square);

	//Cioc
	Mesh* triangle = Object2D::CreateTriangle("triangle", corner, squareSide/4, glm::vec3(1, 0, 0), true);
	AddMeshToList(triangle);

	//Dreptunghiuri
	Mesh* rectangle = Object2D::CreateRectangle("rectangle", corner, 3 * squareSide, glm::vec3(0, 1, 1), true);
	AddMeshToList(rectangle);
}

void Laborator3::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Laborator3::Update(float deltaTimeSeconds)
{
	//PiuPiu este atras de gravitatie
	Yiris -= 100 * deltaTimeSeconds;
	Yeye -= 100 * deltaTimeSeconds;
	Ybody -= 100 * deltaTimeSeconds;
	Ybeak -= 100 * deltaTimeSeconds;

	//Iris
	modelMatrix = glm::mat3(1);
	if (Ybody > 0) {
		modelMatrix *= Transform2D::Translate(520, Yiris);
		RenderMesh2D(meshes["iris"], shaders["VertexColor"], modelMatrix);
	}

	//Ochi
	modelMatrix = glm::mat3(1);
	if (Ybody > 0) {
		modelMatrix *= Transform2D::Translate(510, Yeye);
	}
	else {
		modelMatrix *= Transform2D::Translate(510, 60);
	}
	RenderMesh2D(meshes["eye"], shaders["VertexColor"], modelMatrix);

	//Cioc
	modelMatrix = glm::mat3(1);
	if (Ybody > 0) {
		modelMatrix *= Transform2D::Translate(575, Ybeak);
	}
	else {
		ok = -1;
		modelMatrix *= Transform2D::Translate(575, 50);
	}
	RenderMesh2D(meshes["triangle"], shaders["VertexColor"], modelMatrix);

	//Corp
	modelMatrix = glm::mat3(1);
	if (Ybody > 0) {
		modelMatrix *= Transform2D::Translate(450, Ybody);
	}
	else {
		ok = -1;
		modelMatrix *= Transform2D::Translate(450, 0);
	}
	RenderMesh2D(meshes["square"], shaders["VertexColor"], modelMatrix);

	//Dreptunghiurile se misca dreapta-stanga
	//Viteza creste
	if (ok == 0) {
		X1 -= 100 * deltaTimeSeconds;
		X2 -= 100 * deltaTimeSeconds;
		X3 -= 100 * deltaTimeSeconds;
		X4 -= 100 * deltaTimeSeconds;
		X5 -= 100 * deltaTimeSeconds;
	}
	else if (ok == 1 || ok == 2){
		X1 -= 150 * deltaTimeSeconds;
		X2 -= 150 * deltaTimeSeconds;
		X3 -= 150 * deltaTimeSeconds;
		X4 -= 150 * deltaTimeSeconds;
		X5 -= 150 * deltaTimeSeconds;
	}
	else if (ok == 3 || ok == 4){
		X1 -= 200 * deltaTimeSeconds;
		X2 -= 200 * deltaTimeSeconds;
		X3 -= 200 * deltaTimeSeconds;
		X4 -= 200 * deltaTimeSeconds;
		X5 -= 200 * deltaTimeSeconds;
	}
	else if (ok == 4 || ok == 5){
		X1 -= 250 * deltaTimeSeconds;
		X2 -= 250 * deltaTimeSeconds;
		X3 -= 250 * deltaTimeSeconds;
		X4 -= 250 * deltaTimeSeconds;
		X5 -= 250 * deltaTimeSeconds;
	}
	else if (ok == 6 || ok == 7){
		X1 -= 300 * deltaTimeSeconds;
		X2 -= 300 * deltaTimeSeconds;
		X3 -= 300 * deltaTimeSeconds;
		X4 -= 300 * deltaTimeSeconds;
		X5 -= 300 * deltaTimeSeconds;
	}
	else if (ok >= 8){
		X1 -= 350 * deltaTimeSeconds;
		X2 -= 350 * deltaTimeSeconds;
		X3 -= 350 * deltaTimeSeconds;
		X4 -= 350 * deltaTimeSeconds;
		X5 -= 350 * deltaTimeSeconds;
	}

	//Primul set de dreptunghiuri
	modelMatrix = glm::mat3(1);
	//Dreptunghiul de sus
	if (X1 > 0) {
		if (X1 >= 350 && X1 <= 575 && Ybody >= 400) {
			ok = -1;
		}
		else if (X1 < 350 && ok_score == 1) {
			ok_score = 2;
			score += 100;
			printf("Score: %.1f\n ", score);
		}
		modelMatrix *= Transform2D::Translate(X1, 500);
	}
	else if (ok < 5) {
		X1 = 1650;
	}
	else {
		X1 = 1950;
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Dreptunghiul de jos
	modelMatrix = glm::mat3(1);
	if (X1 > 0) {
		if (X1 >= 350 && X1 <= 575 && Ybody <= 150) {
			ok = -1;	
		}
		modelMatrix *= Transform2D::Translate(X1,-150);
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Al doilea set de dreptunghiuri
	//Dreptunghiul de sus
	modelMatrix = glm::mat3(1);
	if (X2 > 0) {
		if (X2 >= 350 && X2 <= 575 && Ybody >= 500) {
			ok = -1;
		}
		else if (X2 < 350 && ok_score == 2) {
			ok_score = 3;
			score += 100;
			printf("Score: %.1f\n ", score);
		}
		modelMatrix *= Transform2D::Translate(X2, 600);
	}
	else if (ok < 5) {
		X2 = 1650;
	}
	else {
		X2 = 1950;
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Dreptunghiul de jos
	modelMatrix = glm::mat3(1);
	if (X2 > 0) {
		if (X2 >= 350 && X2 <= 575 && Ybody <= 300) {
			ok = -1;
		}
		modelMatrix *= Transform2D::Translate(X2, 0);
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Al treilea set de dreptunghiuri	
	//Dreptunghiul de sus
	modelMatrix = glm::mat3(1);
	if (X3 > 0) {
		if (X3 >= 350 && X3 <= 575 && Ybody >= 400) {
			ok = -1;
		}
		else if (X3 < 350 && ok_score == 3) {
			ok_score = 4;
			score += 100;
			printf("Score: %.1f\n ", score);
		}
		modelMatrix *= Transform2D::Translate(X3, 500);
	}
	else if (ok < 5) {
		X3 = 1650;
	}
	else {
		X3 = 1950;
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);
	
	//Dreptunghiul de jos
	modelMatrix = glm::mat3(1);
	if (X3 > 0) {
		if (X3 >= 350 && X3 <= 575 && Ybody <= 200) {
			ok = -1;
		}
		modelMatrix *= Transform2D::Translate(X3, -100);
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Al patrulea set de dreptunghiuri
	//Dreptunghiul de sus
	modelMatrix = glm::mat3(1);
	if (X4 > 0) {
		if (X4 >= 350 && X4 <= 575 && Ybody >= 400) {
			ok = -1;
		}
		else if (X4 < 350 && ok_score == 4) {
			ok_score = 5;
			score += 100;
			printf("Score: %.1f\n ", score);
		}
		modelMatrix *= Transform2D::Translate(X4, 500);
	}
	else if (ok < 5) {
		X4 = 1650;
	}
	else {
		X4 = 1950;
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Dreptunghiul de jos
	modelMatrix = glm::mat3(1);
	if (X4 > 0) {
		if (X4 >= 350 && X4 <= 575 && Ybody <= 250) {
			ok = -1;
		}
		modelMatrix *= Transform2D::Translate(X4, -50);
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Al cincilea set de dreptunghiuri
	//Dreptunghiul de sus
	modelMatrix = glm::mat3(1);
	if (X5 > 0) {
		if (X5 >= 350 && X5 <= 575 && Ybody >= 450) {
			ok = -1;
		}
		else if (X5 < 350 && ok_score == 5) {
			ok_score = 1;
			score += 100;
			printf("Score: %.1f\n ", score);
		}
		modelMatrix *= Transform2D::Translate(X5, 550);
	}
	else if (ok < 5) {
		ok++;
		X5 = 1650;
	}
	else {
		ok++;
		X5 = 1950;
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Dreptunghiul de jos
	modelMatrix = glm::mat3(1);
	if (X5 > 0) {
		if (X5 >= 350 && X5 <= 575 && Ybody <= 200) {
			ok = -1;
		}
		modelMatrix *= Transform2D::Translate(X5, -100);
	}
	RenderMesh2D(meshes["rectangle"], shaders["VertexColor"], modelMatrix);

	//Terminare joc
	if (ok == -1 && end_game == false) {
		end_game = true;
		printf("Game over!\nTotal score: %.1f", score);
	}
	if (ok == -1) {
		Yeye -= 500 * deltaTimeSeconds;
		Ybody -= 500 * deltaTimeSeconds;
		Ybeak -= 500 * deltaTimeSeconds;
	}

	//Scorul creste daca pasarea este inca in viata
	if (ok != -1) {
		score = score + 0.1;
	}
}

void Laborator3::FrameEnd()
{

}

void Laborator3::OnInputUpdate(float deltaTime, int mods)
{
	
}

void Laborator3::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_SPACE && ok != -1) {
		Yiris += 50;
		Yeye += 50;
		Ybody += 50;
		Ybeak += 50;
	}
}

void Laborator3::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator3::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Laborator3::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Laborator3::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator3::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator3::OnWindowResize(int width, int height)
{
}
