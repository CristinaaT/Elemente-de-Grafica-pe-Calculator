Tomoescu Iulia-Cristina, 334CC

	In implementarea jocului Flappy Bird am folosit urmatoarele variabile:
	bool end_game = pentru ca mesajul final sa nu fie afisat de mai multe ori
	int ok = creste de fiecare data cand cele cinci seturi de dreptunghiuri au trecut o data
(pana cand X-ul corespunzator scade sub 0); il folosesc si pentru crestearea vitezei jocului
	float Xn = coordata X pentru translatia seturilor de dreptunghiuri
	float Yetc = coordata Y pentru translatia componentelor pasarii
	double score = tine minte scorul jucatorului; creste in timp si cu 100 de fiecare data
cand PiuPiu trece de un set de dreptunghiuri
	int ok_score = cele cinci seturi vin consecutiv, unul dupa altul, astfel ca o valoare
cuprinsa intre 1 si 5 ii este atribuita fiecaruia, pentru a nu creste scorul de mai multe
ori, cand se face trecerea printr-un singur obstacol

	Pentru creearea pasarii, pe care am denumit-o PiuPiu, am folosit patru figuri geometrice
un triunghi pentru cioc si trei patrate: unul pentru iris, de culoare neagra, unul pentru
ochi, alb si unul pentru corp, galben.

	In momentul in care o coordonata X scade sub 0, este resetata la o anumita valoare, in
functie de ok. Astfel, jocul devine endless runner, dreptunghiuri venind din partea dreapta
a ecranului mereu.

	Conceptul folosit pentru coliziune, pentru dreptunghiului de sus este urmatorul: daca 
coordonata X este cuprinsa intre 350 si 575 (aproximativ de unde incepe si se termina PiuPiu)
si coordonata Y a corpului lui PiuPiu (fiind cea mai mare parte, corpul atinge prima oara),
careia i se adauga 100 (inaltimea corpului) este mai mare decat coordonata Y a dreptunghiului,
inseamna ca PiuPiu loveste dreptunghiul. In momentul coliziunii ok va deveni -1.
	Pentru dreptunghiul de jos este aproape la fel, singura diferenta facand-o coordonata Y
a corpului; in cazul in care aceasta este mai mica decat cea a dreptunghiului inseamna ca
exista o coliziune. 

	Scorul este afisat mereu dupa trecerea cu succes a unui set de obstacole, iar jocul se
termina atunci cand PiuPiu a cazut sau a lovit un dreptunghi.

	Am lucrat direct in folder-ul cu Laborator3.